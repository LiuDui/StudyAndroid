package pri.lr.myclient;

public class MyClient {
}
